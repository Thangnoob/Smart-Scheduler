package com.myproject.studynow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudynowApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudynowApplication.class, args);
	}

}
